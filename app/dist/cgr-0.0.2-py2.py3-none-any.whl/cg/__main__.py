from .cg import entry_point

if __name__ == '__main__':
    entry_point()
